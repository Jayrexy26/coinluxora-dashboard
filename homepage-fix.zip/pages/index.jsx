export default function Home() {
  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      flexDirection: 'column',
      fontFamily: 'Arial'
    }}>
      <h1>Welcome to CoinLuxora</h1>
      <p>Your Crypto, Forex & Stock Investment Dashboard</p>

      <a href="/dashboard" style={{
        marginTop: '20px',
        padding: '12px 20px',
        background: '#2563eb',
        color: 'white',
        borderRadius: '6px',
        textDecoration: 'none'
      }}>
        Go to Dashboard
      </a>
    </div>
  );
}
